#include <stdio.h>
#include "yad3service.h"
#include "mtm_ex2.h"
int main () {
	printf("Printing all Realtors:\n");
	Map realtorsMap = realtorsMapCreate();

	realtorCreate(realtorsMap, "brizer2@gmail.com", "RealState", 20);

	mtmPrintRealtor(stdout,"brizer2@gmail.com", "RealState");

	realtorDestroy(realtorsMap, "brizer2@gmail.com");

	realtorsMapDestroy(realtorsMap);
	return 0;
}

