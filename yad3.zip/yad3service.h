#ifndef YAD3SERVICE_H_
#define YAD3SERVICE_H_

#include "map.h"
#include "set.h"
#include "apartment_service.h"

typedef struct Realtor_t* Realtor;
struct Realtor_t {
	char* companyName;
	int taxPercentage;
	Map apartmentServices;
};

typedef struct Customer_t* Customer;
struct Customer_t {
	int min_area;
	int min_rooms;
	int max_price;
	int money_spent;
	Set customerOffers;
};

typedef struct offer_t* Offer;
struct offer_t {
	char* realtor_email;
	char* service_name;
	int apartment_id;
	int new_price;
	int status;
};

Map realtorsMapCreate();
void realtorsMapDestroy(Map map);
Realtor realtorCreate(Map realtorsMap, char* email, char* company_name, int tax_percentage);
void realtorDestroy(Map realtorsMap, char* key);

#endif /* YAD3SERVICE_H_ */
