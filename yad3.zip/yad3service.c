#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "yad3service.h"


/*============================================================================*/
/* General Helper functions for map */
/*============================================================================*/

int compareMapKey(constMapKeyElement key1, constMapKeyElement key2) {
	return strcmp(key1, key2);
}

/*============================================================================*/
/* Functions for realtors map */
/*============================================================================*/

MapDataElement copyRealtorStruct(constMapDataElement realtor){
	Realtor tmp_realtor = (Realtor)realtor;
	Realtor new_realtor = malloc(sizeof(*new_realtor));
	new_realtor->companyName = tmp_realtor->companyName;
	new_realtor->taxPercentage = tmp_realtor->taxPercentage;
	new_realtor->apartmentServices = mapCopy(tmp_realtor->apartmentServices);
	return new_realtor;
}

MapKeyElement copyRealtorEmail(constMapKeyElement email) {
	char* key = (char*)email;
	char* dest = malloc(sizeof(*dest));
	strcpy(dest, key);
	return dest;
}

void freeRealtorStruct(MapDataElement realtor) {
	Realtor tmp_realtor = (Realtor)realtor;
	free(tmp_realtor->companyName);
	mapDestroy(tmp_realtor->apartmentServices);
	free(tmp_realtor);
}

void freeRealtorEmail(MapKeyElement key) {
	free(key);
}


/*============================================================================*/
/* Functions for apartmentServices map */
/*============================================================================*/

MapDataElement copyApartmentService(constMapDataElement service){
	ApartmentService new_service = (ApartmentService)service;
	return serviceCopy(new_service);
}

MapKeyElement copyApartmentServiceName(constMapKeyElement service_name) {
	char* key = (char*)service_name;
	char* dest = malloc(sizeof(*dest));
	strcpy(dest, key);
	return dest;
}

void freeApartmentService(MapDataElement service) {
	serviceDestroy(service);
}

void freeApartmentServiceName(MapKeyElement key) {
	free(key);
}


/*============================================================================*/

Map realtorsMapCreate() {
	Map realtors_map = mapCreate(copyRealtorStruct, copyRealtorEmail,
				freeRealtorStruct, freeRealtorEmail, compareMapKey);
	return realtors_map;
}

void realtorsMapDestroy(Map realtorsMap) {
	mapDestroy(realtorsMap);
}

Realtor realtorCreate(Map realtorsMap, char* email, char* company_name, int tax_percentage) {
	Realtor new_realtor = malloc(sizeof(*new_realtor));
	// WHAT ABOUT NULLITY CHECK?
	char* new_company_name = malloc(sizeof(*new_company_name));
	new_realtor->companyName = new_company_name;
	new_realtor->taxPercentage = tax_percentage;

	Map new_map = mapCreate(copyApartmentService, copyApartmentServiceName,
			freeApartmentService, freeApartmentServiceName, compareMapKey);

	new_realtor->apartmentServices = new_map;
	char* new_email = malloc(sizeof(*new_email));
	mapPut(realtorsMap, new_email, new_realtor);
	return new_realtor;
}

void realtorDestroy(Map realtorsMap, char* key) {
	free(mapGet(realtorsMap, key));
	mapRemove(realtorsMap, (char*)key);
}

